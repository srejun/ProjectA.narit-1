var location = {}
location =[
        {
            "location": "A",
        },
        {
            "location": "B",
        },
        {
            "location": "C",
        },
        {
            "location": "D",
        }
    ]

class lo {
    addlo(){
        return (location)
    }
}
module.exports = lo
