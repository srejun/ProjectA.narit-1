const express = require('express')/////
const bodyParser = require('body-parser')//////
const cookieParser = require('cookie-parser')///////
const session = require('express-session')//////
const validator = require('express-validator')//////
const cors = require('cors')//////
const app = express()
app.use(validator())
app.use(cookieParser())
app.use(bodyParser.json())
app.use(cors({
  origin:['http://localhost:8080'],
  methods:['GET','POST'],
  credentials: true ,// enable set cookie
}));
app.use(bodyParser.urlencoded({
  extended: false
}))
 const clientSessions = require("client-sessions");
app.use(clientSessions({
  secret: '0GBlJZ9EKBt2Zbi2flRPvztczCewBxXK' // set this to a long random string!
})); 
app.use(session({
  secret: 'keyboard cat555',
  cookieName: 'mySession',
  resave:false,
  saveUninitialized:true


}))

/////////////////////////////////////////////////////////////////////

///show all user only admin can see all admin & user
var show=require('./tool/show')
app.post('/showuser',show.go )

///logout user&admin
var Lout=require('./tool/logout')
app.post('/logout', Lout.go);


///login user&admin
var Lin=require('./tool/login')
app.post('/login',Lin.go)

////delete user&admin
var del=require('./tool/dis')
app.post('/disableuser',del.go)
///regis,add user&admin
var reg=require('./tool/regis')
app.post('/register', reg.go)
      
//edit password///          
var Cpass=require('./tool/edit')
app.post('/edituser', Cpass.go);

var intput = require('./tool/inputdata')
app.post('/api/inputdata', intput.go)
var getalldata = require('./tool/getalldata')
app.post('/api/getallsensor', getalldata.go)
var newlocation = require('./tool/newlocation')
app.post('/api/newlocation', newlocation.go)
var getdatabytime = require('./tool/getdatabytime')
app.post('/api/getdbytime', getdatabytime.go)
var plotgraph = require('./tool/plotgraph')
app.post('/api/getgraph', plotgraph.go)
var examinput = require('./tool/examinput')
app.post('/api/testinput', examinput.go)

var test = require('./tool/test')
app.post('/api/test', test.go) //sensor input update data

///////////////////////////////////////////////////////////////////////////////

var server = app.listen(8081, function () {
  var host = server.address().address
  var port = server.address().port
  console.log("Application run at http://%s:%s", host, port)
})
